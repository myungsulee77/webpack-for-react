import React, { Component } from 'react';
//import { Breadcrumb, BreadcrumbItem, Card, CardBody, CardHeader, Col, Row } from 'reactstrap';

class Breadcrumbs extends Component {
  render() {
    return (
      <div className="animated fadeIn">
        Breadcrumbs
      </div>
    );
  }
}

export default Breadcrumbs;
