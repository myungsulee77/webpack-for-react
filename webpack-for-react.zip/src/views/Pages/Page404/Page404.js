import React, { Component } from 'react';

class Page404 extends Component {
  render() {
    return (
      <div className="app flex-row align-items-center">

      </div>
    );
  }
}

export default Page404;
