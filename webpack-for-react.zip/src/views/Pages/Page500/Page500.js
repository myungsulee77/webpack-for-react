import React, { Component } from 'react';

class Page500 extends Component {
  render() {
    return (
      <div className="app flex-row align-items-center">

      </div>
    );
  }
}

export default Page500;
