import React, { Component } from 'react';

class Register extends Component {
  render() {
    return (
      <div className="app flex-row align-items-center">

      </div>
    );
  }
}

export default Register;
