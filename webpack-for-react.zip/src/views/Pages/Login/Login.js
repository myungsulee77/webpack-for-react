import React, { Component } from 'react';

class Login extends Component {
  render() {
    return (
      <div className="app flex-row align-items-center">

      </div>
    );
  }
}

export default Login;
