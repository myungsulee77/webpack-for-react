import React from 'react';

//const Breadcrumbs = React.lazy(() => import('./views/Base/Breadcrumbs'));


// https://github.com/ReactTraining/react-router/tree/master/packages/react-router-config
const routes = [
  { path: '/', exact: true, name: 'Home' },


];

export default routes;
